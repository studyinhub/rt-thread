

function addToast(msg,timeout=1000) {
    $.Toast("Notice", msg, "success", {
        stack: false,
        has_icon: true,
        has_close_btn: true,
        fullscreen: true,
        timeout: timeout,
        sticky: false,
        has_progress: true,
        rtl: false,
    });
}


// function load_config() {
//     return new Promise((resolve, reject) => {

//         $.get("./config.json", function (response) {
//             console.log('2准备保存配置文件');
//             localStorage.setItem('config', JSON.stringify(response));
//             resolve(response)
//         })
//     }).then((response) => {
//         config = response
//         console.log('config', config)
//     })
// }

async function load_config() {

    const response_1 = await new Promise((resolve, reject) => {
        var load_from_file = false
        if(load_from_file){
            // 从文件系统中的配置文件获取
            $.get("./config.json", function (response) {
                console.log('async load config from config.json');
                localStorage.setItem('config', JSON.stringify(response));
                resolve(response);
            });
        }else
        {
            // 从 API 中获取
            $.get("cgi-bin/get_config", function (response) {
                console.log('async load config from api get_config');
                localStorage.setItem('config', response);
                resolve(JSON.parse(response));
            }); 
        }
    });
    config = response_1;
    console.log('config', config);
}

async function put_config(config) {
    return await new Promise((resolve, reject) => {
        console.log("put_config 开始更新配置")
        $.post("cgi-bin/put_config", config, (res) => {
            console.log('post res:', res)
            resolve(res)
        })
    })
}

